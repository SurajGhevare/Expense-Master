package com.expensetracker.ui.friends

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.FriendBalance
import com.expensetracker.databinding.ItemFriendBalanceBinding
import com.expensetracker.util.DateTimeUtil

class FriendBalanceAdapter(
    private val onFriendClick: (Long) -> Unit
) : ListAdapter<FriendBalance, FriendBalanceAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemFriendBalanceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(balance: FriendBalance) {
            binding.tvName.text = balance.friendName
            binding.tvInitial.text = balance.friendName.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            binding.tvTotalOwed.text = "Total: ${DateTimeUtil.formatCurrency(balance.totalOwed)}"

            if (balance.pendingAmount > 0) {
                binding.tvPending.text = "Owes: ${DateTimeUtil.formatCurrency(balance.pendingAmount)}"
                binding.tvPending.setTextColor(Color.parseColor("#E53935"))
            } else {
                binding.tvPending.text = "All settled ✓"
                binding.tvPending.setTextColor(Color.parseColor("#43A047"))
            }

            binding.root.setOnClickListener { onFriendClick(balance.friendId) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemFriendBalanceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class DiffCallback : DiffUtil.ItemCallback<FriendBalance>() {
        override fun areItemsTheSame(oldItem: FriendBalance, newItem: FriendBalance) = oldItem.friendId == newItem.friendId
        override fun areContentsTheSame(oldItem: FriendBalance, newItem: FriendBalance) = oldItem == newItem
    }
}
