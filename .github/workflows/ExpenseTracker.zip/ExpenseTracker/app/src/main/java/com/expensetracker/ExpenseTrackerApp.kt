package com.expensetracker

import android.app.Application
import com.expensetracker.data.db.AppDatabase
import com.expensetracker.data.repository.ExpenseRepository

class ExpenseTrackerApp : Application() {

    val database by lazy { AppDatabase.getInstance(this) }
    val repository by lazy { ExpenseRepository(database) }
}
