package com.expensetracker.ui.friends

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.R
import com.expensetracker.databinding.FragmentFriendsBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory

class FriendsFragment : Fragment() {

    private var _binding: FragmentFriendsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    private lateinit var friendsAdapter: FriendsAdapter
    private lateinit var balancesAdapter: FriendBalanceAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFriendsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupAdapters()
        setupTabs()
        observeData()

        binding.fabAddFriend.setOnClickListener {
            AddEditFriendDialog(requireContext(), null) { friend ->
                viewModel.addFriend(friend)
            }.show()
        }
    }

    private fun setupAdapters() {
        friendsAdapter = FriendsAdapter(
            onEdit = { friend ->
                AddEditFriendDialog(requireContext(), friend) { updatedFriend ->
                    viewModel.updateFriend(updatedFriend)
                }.show()
            },
            onDelete = { friend ->
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Friend")
                    .setMessage("Delete ${friend.name}? Their expense splits will also be removed.")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteFriend(friend) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )

        balancesAdapter = FriendBalanceAdapter { friendId ->
            val bundle = Bundle().apply { putLong("friendId", friendId) }
            findNavController().navigate(R.id.action_friends_to_friendDetail, bundle)
        }

        binding.rvFriends.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = friendsAdapter
        }

        binding.rvBalances.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = balancesAdapter
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object :
            com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> {
                        binding.rvFriends.visibility = View.VISIBLE
                        binding.rvBalances.visibility = View.GONE
                    }
                    1 -> {
                        binding.rvFriends.visibility = View.GONE
                        binding.rvBalances.visibility = View.VISIBLE
                    }
                }
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
        })
    }

    private fun observeData() {
        viewModel.allFriends.observe(viewLifecycleOwner) { friends ->
            friendsAdapter.submitList(friends)
            binding.tvNoFriends.visibility = if (friends.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.friendBalances.observe(viewLifecycleOwner) { balances ->
            balancesAdapter.submitList(balances)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
