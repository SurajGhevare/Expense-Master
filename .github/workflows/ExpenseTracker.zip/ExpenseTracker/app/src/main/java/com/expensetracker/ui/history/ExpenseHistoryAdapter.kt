package com.expensetracker.ui.history

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.Expense
import com.expensetracker.databinding.*
import com.expensetracker.util.DateTimeUtil

class ExpenseHistoryAdapter(
    private val onExpenseClick: (Expense) -> Unit
) : ListAdapter<HistoryItem, RecyclerView.ViewHolder>(DiffCallback()) {

    companion object {
        const val TYPE_YEAR = 0
        const val TYPE_MONTH = 1
        const val TYPE_DATE = 2
        const val TYPE_EXPENSE = 3
    }

    override fun getItemViewType(position: Int) = when (getItem(position)) {
        is HistoryItem.YearHeader -> TYPE_YEAR
        is HistoryItem.MonthHeader -> TYPE_MONTH
        is HistoryItem.DateHeader -> TYPE_DATE
        is HistoryItem.ExpenseItem -> TYPE_EXPENSE
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_YEAR -> YearViewHolder(ItemHistoryYearBinding.inflate(inflater, parent, false))
            TYPE_MONTH -> MonthViewHolder(ItemHistoryMonthBinding.inflate(inflater, parent, false))
            TYPE_DATE -> DateViewHolder(ItemHistoryDateBinding.inflate(inflater, parent, false))
            else -> ExpenseViewHolder(ItemHistoryExpenseBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is HistoryItem.YearHeader -> (holder as YearViewHolder).bind(item)
            is HistoryItem.MonthHeader -> (holder as MonthViewHolder).bind(item)
            is HistoryItem.DateHeader -> (holder as DateViewHolder).bind(item)
            is HistoryItem.ExpenseItem -> (holder as ExpenseViewHolder).bind(item.expense)
        }
    }

    inner class YearViewHolder(private val binding: ItemHistoryYearBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: HistoryItem.YearHeader) {
            binding.tvYear.text = item.year
        }
    }

    inner class MonthViewHolder(private val binding: ItemHistoryMonthBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: HistoryItem.MonthHeader) {
            binding.tvMonth.text = item.monthYear
            binding.tvMonthTotal.text = DateTimeUtil.formatCurrency(item.total)
        }
    }

    inner class DateViewHolder(private val binding: ItemHistoryDateBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: HistoryItem.DateHeader) {
            binding.tvDate.text = item.date
            binding.tvDayOfWeek.text = item.dayOfWeek
        }
    }

    inner class ExpenseViewHolder(private val binding: ItemHistoryExpenseBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(expense: Expense) {
            binding.tvDescription.text = expense.description
            binding.tvAmount.text = DateTimeUtil.formatCurrency(expense.amount)
            binding.tvCategory.text = expense.category
            binding.tvTime.text = DateTimeUtil.formatTime(expense.createdAt)
            binding.root.setOnClickListener { onExpenseClick(expense) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<HistoryItem>() {
        override fun areItemsTheSame(oldItem: HistoryItem, newItem: HistoryItem): Boolean {
            return when {
                oldItem is HistoryItem.ExpenseItem && newItem is HistoryItem.ExpenseItem ->
                    oldItem.expense.id == newItem.expense.id
                oldItem is HistoryItem.YearHeader && newItem is HistoryItem.YearHeader ->
                    oldItem.year == newItem.year
                oldItem is HistoryItem.MonthHeader && newItem is HistoryItem.MonthHeader ->
                    oldItem.monthYear == newItem.monthYear
                oldItem is HistoryItem.DateHeader && newItem is HistoryItem.DateHeader ->
                    oldItem.date == newItem.date
                else -> false
            }
        }

        override fun areContentsTheSame(oldItem: HistoryItem, newItem: HistoryItem) =
            oldItem == newItem
    }
}
