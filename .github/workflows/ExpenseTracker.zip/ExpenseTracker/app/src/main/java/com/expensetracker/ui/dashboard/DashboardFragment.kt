package com.expensetracker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.R
import com.expensetracker.databinding.FragmentDashboardBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory
import com.expensetracker.util.DateTimeUtil

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    private lateinit var recentExpensesAdapter: RecentExpensesAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeData()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        recentExpensesAdapter = RecentExpensesAdapter { expense ->
            val bundle = Bundle().apply { putLong("expenseId", expense.id) }
            findNavController().navigate(R.id.action_dashboard_to_expenseDetail, bundle)
        }
        binding.rvRecentExpenses.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = recentExpensesAdapter
        }
    }

    private fun observeData() {
        viewModel.totalSpent.observe(viewLifecycleOwner) { total ->
            binding.tvTotalSpent.text = DateTimeUtil.formatCurrency(total ?: 0.0)
        }

        viewModel.totalPending.observe(viewLifecycleOwner) { pending ->
            binding.tvTotalPending.text = DateTimeUtil.formatCurrency(pending ?: 0.0)
        }

        viewModel.recentExpenses.observe(viewLifecycleOwner) { expenses ->
            recentExpensesAdapter.submitList(expenses)
            binding.tvNoExpenses.visibility = if (expenses.isEmpty()) View.VISIBLE else View.GONE
            binding.rvRecentExpenses.visibility = if (expenses.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.friendBalances.observe(viewLifecycleOwner) { balances ->
            val friendsOwing = balances.count { it.pendingAmount > 0 }
            binding.tvFriendsOwing.text = "$friendsOwing"
        }

        viewModel.monthlyExpenseSummary.observe(viewLifecycleOwner) { summary ->
            if (summary.isNotEmpty()) {
                val current = summary.first()
                val monthName = DateTimeUtil.getMonthName(current.month.toInt())
                binding.tvThisMonth.text = DateTimeUtil.formatCurrency(current.total)
                binding.tvThisMonthLabel.text = "Spent in $monthName"
            }
        }
    }

    private fun setupClickListeners() {
        binding.fabAddExpense.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_addExpense)
        }

        binding.cardTotalPending.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_friends)
        }

        binding.tvSeeAll.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_history)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
