package com.expensetracker.ui.friends

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.ExpenseSplitWithFriend
import com.expensetracker.databinding.ItemFriendExpenseBinding
import com.expensetracker.util.DateTimeUtil

class FriendExpenseAdapter(
    private val onPaymentToggle: (Long, Boolean) -> Unit
) : ListAdapter<ExpenseSplitWithFriend, FriendExpenseAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemFriendExpenseBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ExpenseSplitWithFriend) {
            binding.tvDescription.text = item.expenseDescription
            binding.tvDate.text = DateTimeUtil.formatDate(item.createdAt)
            binding.tvSplitAmount.text = DateTimeUtil.formatCurrency(item.splitAmount)
            binding.tvTotalAmount.text = "Total: ${DateTimeUtil.formatCurrency(item.totalAmount)}"

            binding.switchPaid.setOnCheckedChangeListener(null)
            binding.switchPaid.isChecked = item.isPaid

            if (item.isPaid) {
                binding.tvStatus.text = "Paid ✓"
                binding.tvStatus.setTextColor(Color.parseColor("#43A047"))
            } else {
                binding.tvStatus.text = "Pending"
                binding.tvStatus.setTextColor(Color.parseColor("#E53935"))
            }

            binding.switchPaid.setOnCheckedChangeListener { _, isChecked ->
                onPaymentToggle(item.splitId, isChecked)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemFriendExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class DiffCallback : DiffUtil.ItemCallback<ExpenseSplitWithFriend>() {
        override fun areItemsTheSame(oldItem: ExpenseSplitWithFriend, newItem: ExpenseSplitWithFriend) =
            oldItem.splitId == newItem.splitId
        override fun areContentsTheSame(oldItem: ExpenseSplitWithFriend, newItem: ExpenseSplitWithFriend) =
            oldItem == newItem
    }
}
