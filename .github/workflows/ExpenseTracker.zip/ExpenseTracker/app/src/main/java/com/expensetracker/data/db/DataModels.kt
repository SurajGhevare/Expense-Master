package com.expensetracker.data.db

import androidx.room.Embedded
import androidx.room.Relation

data class ExpenseWithSplits(
    @Embedded val expense: Expense,
    @Relation(
        parentColumn = "id",
        entityColumn = "expenseId"
    )
    val splits: List<ExpenseSplit>
)

data class FriendBalance(
    val friendId: Long,
    val friendName: String,
    val totalOwed: Double,
    val paidAmount: Double
) {
    val pendingAmount: Double get() = totalOwed - paidAmount
}

data class ExpenseSplitWithFriend(
    val splitId: Long,
    val expenseId: Long,
    val friendId: Long,
    val friendName: String,
    val expenseDescription: String,
    val splitAmount: Double,
    val isPaid: Boolean,
    val createdAt: Long,
    val totalAmount: Double
)
