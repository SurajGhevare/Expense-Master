package com.expensetracker.ui.friends

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import com.expensetracker.data.db.Friend
import com.expensetracker.databinding.DialogAddFriendBinding

class AddEditFriendDialog(
    private val context: Context,
    private val friend: Friend?,
    private val onSave: (Friend) -> Unit
) {
    fun show() {
        val binding = DialogAddFriendBinding.inflate(LayoutInflater.from(context))

        friend?.let {
            binding.etName.setText(it.name)
            binding.etEmail.setText(it.email)
            binding.etPhone.setText(it.phone)
        }

        AlertDialog.Builder(context)
            .setTitle(if (friend == null) "Add Friend" else "Edit Friend")
            .setView(binding.root)
            .setPositiveButton(if (friend == null) "Add" else "Save") { _, _ ->
                val name = binding.etName.text.toString().trim()
                val email = binding.etEmail.text.toString().trim()
                val phone = binding.etPhone.text.toString().trim()

                if (name.isNotEmpty()) {
                    val updatedFriend = if (friend != null) {
                        friend.copy(name = name, email = email, phone = phone)
                    } else {
                        Friend(name = name, email = email, phone = phone)
                    }
                    onSave(updatedFriend)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
