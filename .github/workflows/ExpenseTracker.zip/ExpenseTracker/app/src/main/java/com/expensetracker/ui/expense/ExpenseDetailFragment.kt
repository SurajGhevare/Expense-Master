package com.expensetracker.ui.expense

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.R
import com.expensetracker.databinding.FragmentExpenseDetailBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory
import com.expensetracker.util.DateTimeUtil
import kotlinx.coroutines.launch

class ExpenseDetailFragment : Fragment() {

    private var _binding: FragmentExpenseDetailBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    private var expenseId: Long = -1

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExpenseDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        expenseId = arguments?.getLong("expenseId", -1) ?: -1

        binding.btnBack.setOnClickListener { findNavController().navigateUp() }

        binding.btnEdit.setOnClickListener {
            val bundle = Bundle().apply { putLong("expenseId", expenseId) }
            findNavController().navigate(R.id.action_expenseDetail_to_addExpense, bundle)
        }

        binding.btnDelete.setOnClickListener {
            showDeleteConfirmation()
        }

        loadExpenseDetails()
    }

    private fun loadExpenseDetails() {
        lifecycleScope.launch {
            val expenseWithSplits = viewModel.getExpenseWithSplitsById(expenseId)
            expenseWithSplits?.let { ews ->
                val expense = ews.expense
                binding.tvDescription.text = expense.description
                binding.tvAmount.text = DateTimeUtil.formatCurrency(expense.amount)
                binding.tvDate.text = DateTimeUtil.formatDateTime(expense.createdAt)
                binding.tvCategory.text = expense.category
                binding.tvNotes.text = if (expense.notes.isEmpty()) "No notes" else expense.notes

                if (ews.splits.isEmpty()) {
                    binding.tvSplitsLabel.visibility = View.GONE
                    binding.rvSplits.visibility = View.GONE
                    binding.tvNoSplits.visibility = View.VISIBLE
                } else {
                    binding.tvSplitsLabel.visibility = View.VISIBLE
                    binding.rvSplits.visibility = View.VISIBLE
                    binding.tvNoSplits.visibility = View.GONE

                    val adapter = SplitDetailAdapter(ews.splits) { splitId, isPaid ->
                        viewModel.markSplitAsPaid(splitId, isPaid)
                        loadExpenseDetails()
                    }
                    binding.rvSplits.layoutManager = LinearLayoutManager(requireContext())
                    binding.rvSplits.adapter = adapter
                }
            }
        }
    }

    private fun showDeleteConfirmation() {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Expense")
            .setMessage("Are you sure you want to delete this expense?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    val expenseWithSplits = viewModel.getExpenseWithSplitsById(expenseId)
                    expenseWithSplits?.let {
                        viewModel.deleteExpense(it.expense)
                        findNavController().navigateUp()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
