package com.expensetracker.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.Expense
import com.expensetracker.databinding.ItemRecentExpenseBinding
import com.expensetracker.util.DateTimeUtil

class RecentExpensesAdapter(
    private val onItemClick: (Expense) -> Unit
) : ListAdapter<Expense, RecentExpensesAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemRecentExpenseBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(expense: Expense) {
            binding.tvDescription.text = expense.description
            binding.tvAmount.text = DateTimeUtil.formatCurrency(expense.amount)
            binding.tvDate.text = DateTimeUtil.formatDate(expense.createdAt)
            binding.tvCategory.text = expense.category

            val initial = expense.category.firstOrNull()?.uppercaseChar() ?: 'E'
            binding.tvCategoryInitial.text = initial.toString()

            binding.root.setOnClickListener { onItemClick(expense) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecentExpenseBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<Expense>() {
        override fun areItemsTheSame(oldItem: Expense, newItem: Expense) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Expense, newItem: Expense) = oldItem == newItem
    }
}
