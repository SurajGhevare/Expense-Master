package com.expensetracker.ui.expense

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.data.db.Expense
import com.expensetracker.data.db.Friend
import com.expensetracker.databinding.FragmentAddExpenseBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory
import com.expensetracker.util.DateTimeUtil
import kotlinx.coroutines.launch

class AddExpenseFragment : Fragment() {

    private var _binding: FragmentAddExpenseBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    private val selectedFriendIds = mutableSetOf<Long>()
    private var friendsList = listOf<Friend>()
    private var editingExpenseId: Long = -1

    private val categories = listOf("Food", "Transport", "Entertainment", "Shopping", "Travel", "Medical", "Education", "General", "Other")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        editingExpenseId = arguments?.getLong("expenseId", -1) ?: -1

        setupCategoryDropdown()
        setupFriendSelection()
        setupSaveButton()

        if (editingExpenseId != -1L) {
            loadExpenseForEditing()
            binding.tvTitle.text = "Edit Expense"
            binding.btnSave.text = "Update Expense"
        } else {
            binding.tvTitle.text = "Add Expense"
        }

        binding.tvDate.text = DateTimeUtil.formatDateTime(System.currentTimeMillis())

        binding.btnBack.setOnClickListener { findNavController().navigateUp() }
    }

    private fun setupCategoryDropdown() {
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, categories)
        binding.actvCategory.setAdapter(adapter)
        binding.actvCategory.setText("General", false)
    }

    private fun setupFriendSelection() {
        viewModel.allFriends.observe(viewLifecycleOwner) { friends ->
            friendsList = friends
            updateFriendChips(friends)
        }
    }

    private fun updateFriendChips(friends: List<Friend>) {
        binding.chipGroupFriends.removeAllViews()
        friends.forEach { friend ->
            val chip = com.google.android.material.chip.Chip(requireContext()).apply {
                text = friend.name
                isCheckable = true
                isChecked = selectedFriendIds.contains(friend.id)
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) selectedFriendIds.add(friend.id)
                    else selectedFriendIds.remove(friend.id)
                    updateSplitPreview()
                }
            }
            binding.chipGroupFriends.addView(chip)
        }

        if (friends.isEmpty()) {
            binding.tvNoFriends.visibility = View.VISIBLE
            binding.chipGroupFriends.visibility = View.GONE
        } else {
            binding.tvNoFriends.visibility = View.GONE
            binding.chipGroupFriends.visibility = View.VISIBLE
        }
    }

    private fun updateSplitPreview() {
        val amountStr = binding.etAmount.text.toString()
        val amount = amountStr.toDoubleOrNull() ?: 0.0

        if (selectedFriendIds.isEmpty() || amount == 0.0) {
            binding.cardSplitPreview.visibility = View.GONE
            return
        }

        binding.cardSplitPreview.visibility = View.VISIBLE
        val splitAmount = amount / selectedFriendIds.size
        val friendNames = friendsList
            .filter { selectedFriendIds.contains(it.id) }
            .joinToString(", ") { it.name }

        binding.tvSplitInfo.text = "Split equally among ${selectedFriendIds.size} people"
        binding.tvSplitAmount.text = "Each owes: ${DateTimeUtil.formatCurrency(splitAmount)}"
        binding.tvSplitFriends.text = friendNames
    }

    private fun setupSaveButton() {
        binding.etAmount.setOnFocusChangeListener { _, _ -> updateSplitPreview() }

        binding.btnSave.setOnClickListener {
            if (validateInputs()) saveExpense()
        }
    }

    private fun validateInputs(): Boolean {
        val amount = binding.etAmount.text.toString()
        val description = binding.etDescription.text.toString()

        if (amount.isEmpty()) {
            binding.tilAmount.error = "Amount is required"
            return false
        }
        binding.tilAmount.error = null

        if (amount.toDoubleOrNull() == null || amount.toDouble() <= 0) {
            binding.tilAmount.error = "Enter a valid amount"
            return false
        }
        binding.tilAmount.error = null

        if (description.isEmpty()) {
            binding.tilDescription.error = "Description is required"
            return false
        }
        binding.tilDescription.error = null

        return true
    }

    private fun saveExpense() {
        val amount = binding.etAmount.text.toString().toDouble()
        val description = binding.etDescription.text.toString().trim()
        val category = binding.actvCategory.text.toString().trim().ifEmpty { "General" }
        val notes = binding.etNotes.text.toString().trim()

        val expense = if (editingExpenseId != -1L) {
            Expense(
                id = editingExpenseId,
                amount = amount,
                description = description,
                category = category,
                notes = notes
            )
        } else {
            Expense(
                amount = amount,
                description = description,
                category = category,
                notes = notes
            )
        }

        if (editingExpenseId != -1L) {
            viewModel.updateExpenseWithSplits(expense, selectedFriendIds.toList())
            Toast.makeText(requireContext(), "Expense updated!", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.addExpenseWithSplits(expense, selectedFriendIds.toList())
            Toast.makeText(requireContext(), "Expense added!", Toast.LENGTH_SHORT).show()
        }

        findNavController().navigateUp()
    }

    private fun loadExpenseForEditing() {
        lifecycleScope.launch {
            val expenseWithSplits = viewModel.getExpenseWithSplitsById(editingExpenseId)
            expenseWithSplits?.let { ews ->
                val expense = ews.expense
                binding.etAmount.setText(expense.amount.toString())
                binding.etDescription.setText(expense.description)
                binding.actvCategory.setText(expense.category, false)
                binding.etNotes.setText(expense.notes)
                binding.tvDate.text = DateTimeUtil.formatDateTime(expense.createdAt)

                selectedFriendIds.clear()
                selectedFriendIds.addAll(ews.splits.map { it.friendId })

                // Refresh chips with pre-selected friends
                friendsList.let { updateFriendChips(it) }
                updateSplitPreview()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
