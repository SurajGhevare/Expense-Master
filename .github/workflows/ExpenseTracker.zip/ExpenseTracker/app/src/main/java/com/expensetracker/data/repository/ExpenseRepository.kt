package com.expensetracker.data.repository

import com.expensetracker.data.db.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ExpenseRepository(private val db: AppDatabase) {

    val allExpenses = db.expenseDao().getAllExpenses()
    val allExpensesWithSplits = db.expenseDao().getAllExpensesWithSplits()
    val totalSpent = db.expenseDao().getTotalSpent()
    val totalPending = db.expenseDao().getTotalPending()
    val recentExpenses = db.expenseDao().getRecentExpenses(10)
    val friendBalances = db.friendDao().getFriendBalances()
    val allFriends = db.friendDao().getAllFriends()
    val monthlyExpenseSummary = db.expenseDao().getMonthlyExpenseSummary()

    suspend fun addExpenseWithSplits(
        expense: Expense,
        friendIds: List<Long>
    ): Long = withContext(Dispatchers.IO) {
        val expenseId = db.expenseDao().insertExpense(expense)
        if (friendIds.isNotEmpty()) {
            val splitAmount = expense.amount / friendIds.size
            val splits = friendIds.map { friendId ->
                ExpenseSplit(
                    expenseId = expenseId,
                    friendId = friendId,
                    splitAmount = splitAmount
                )
            }
            db.expenseDao().insertSplits(splits)
        }
        expenseId
    }

    suspend fun updateExpenseWithSplits(
        expense: Expense,
        friendIds: List<Long>
    ) = withContext(Dispatchers.IO) {
        db.expenseDao().updateExpense(expense)
        db.expenseDao().deleteSplitsForExpense(expense.id)
        if (friendIds.isNotEmpty()) {
            val splitAmount = expense.amount / friendIds.size
            val splits = friendIds.map { friendId ->
                ExpenseSplit(
                    expenseId = expense.id,
                    friendId = friendId,
                    splitAmount = splitAmount
                )
            }
            db.expenseDao().insertSplits(splits)
        }
    }

    suspend fun deleteExpense(expense: Expense) = withContext(Dispatchers.IO) {
        db.expenseDao().deleteExpense(expense)
    }

    suspend fun getExpenseWithSplitsById(id: Long) = withContext(Dispatchers.IO) {
        db.expenseDao().getExpenseWithSplitsById(id)
    }

    suspend fun markSplitAsPaid(splitId: Long, isPaid: Boolean) = withContext(Dispatchers.IO) {
        db.expenseDao().updateSplitPaymentStatus(
            splitId = splitId,
            isPaid = isPaid,
            paidAt = if (isPaid) System.currentTimeMillis() else null
        )
    }

    // Friends
    suspend fun addFriend(friend: Friend): Long = withContext(Dispatchers.IO) {
        db.friendDao().insertFriend(friend)
    }

    suspend fun updateFriend(friend: Friend) = withContext(Dispatchers.IO) {
        db.friendDao().updateFriend(friend)
    }

    suspend fun deleteFriend(friend: Friend) = withContext(Dispatchers.IO) {
        db.friendDao().deleteFriend(friend)
    }

    suspend fun getAllFriendsSync() = withContext(Dispatchers.IO) {
        db.friendDao().getAllFriendsSync()
    }

    fun getExpensesForFriend(friendId: Long) = db.friendDao().getExpensesForFriend(friendId)
}
