package com.expensetracker.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.R
import com.expensetracker.data.db.Expense
import com.expensetracker.databinding.FragmentExpenseHistoryBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory
import com.expensetracker.util.DateTimeUtil

sealed class HistoryItem {
    data class YearHeader(val year: String) : HistoryItem()
    data class MonthHeader(val monthYear: String, val total: Double) : HistoryItem()
    data class DateHeader(val date: String, val dayOfWeek: String) : HistoryItem()
    data class ExpenseItem(val expense: Expense) : HistoryItem()
}

class ExpenseHistoryFragment : Fragment() {

    private var _binding: FragmentExpenseHistoryBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    private lateinit var historyAdapter: ExpenseHistoryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExpenseHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        historyAdapter = ExpenseHistoryAdapter { expense ->
            val bundle = Bundle().apply { putLong("expenseId", expense.id) }
            findNavController().navigate(R.id.action_history_to_expenseDetail, bundle)
        }

        binding.rvHistory.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = historyAdapter
        }

        binding.fabAddExpense.setOnClickListener {
            findNavController().navigate(R.id.action_history_to_addExpense)
        }

        viewModel.allExpenses.observe(viewLifecycleOwner) { expenses ->
            if (expenses.isEmpty()) {
                binding.tvEmpty.visibility = View.VISIBLE
                binding.rvHistory.visibility = View.GONE
            } else {
                binding.tvEmpty.visibility = View.GONE
                binding.rvHistory.visibility = View.VISIBLE
                historyAdapter.submitList(buildHistoryItems(expenses))
            }
        }
    }

    private fun buildHistoryItems(expenses: List<Expense>): List<HistoryItem> {
        val items = mutableListOf<HistoryItem>()
        var currentYear = ""
        var currentMonth = ""
        var currentDate = ""

        expenses.forEach { expense ->
            val year = DateTimeUtil.getYear(expense.createdAt)
            val monthYear = DateTimeUtil.getMonthYear(expense.createdAt)
            val date = DateTimeUtil.formatDate(expense.createdAt)
            val dayOfWeek = DateTimeUtil.getDayOfWeek(expense.createdAt)

            if (year != currentYear) {
                items.add(HistoryItem.YearHeader(year))
                currentYear = year
                currentMonth = ""
                currentDate = ""
            }

            if (monthYear != currentMonth) {
                val monthTotal = expenses
                    .filter { DateTimeUtil.getMonthYear(it.createdAt) == monthYear }
                    .sumOf { it.amount }
                items.add(HistoryItem.MonthHeader(monthYear, monthTotal))
                currentMonth = monthYear
                currentDate = ""
            }

            if (date != currentDate) {
                items.add(HistoryItem.DateHeader(date, dayOfWeek))
                currentDate = date
            }

            items.add(HistoryItem.ExpenseItem(expense))
        }

        return items
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
