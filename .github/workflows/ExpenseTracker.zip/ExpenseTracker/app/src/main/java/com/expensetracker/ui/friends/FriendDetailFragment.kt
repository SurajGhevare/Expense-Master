package com.expensetracker.ui.friends

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.databinding.FragmentFriendDetailBinding
import com.expensetracker.ui.MainViewModel
import com.expensetracker.ui.MainViewModelFactory
import com.expensetracker.util.DateTimeUtil
import androidx.navigation.fragment.findNavController

class FriendDetailFragment : Fragment() {

    private var _binding: FragmentFriendDetailBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels {
        MainViewModelFactory((requireActivity().application as ExpenseTrackerApp).repository)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFriendDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val friendId = arguments?.getLong("friendId", -1) ?: -1
        binding.btnBack.setOnClickListener { findNavController().navigateUp() }

        viewModel.allFriends.observe(viewLifecycleOwner) { friends ->
            val friend = friends.find { it.id == friendId }
            friend?.let {
                binding.tvFriendName.text = it.name
                binding.tvInitial.text = it.name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
                binding.tvEmail.text = it.email.ifEmpty { "No email" }
                binding.tvPhone.text = it.phone.ifEmpty { "No phone" }
            }
        }

        val adapter = FriendExpenseAdapter { splitId, isPaid ->
            viewModel.markSplitAsPaid(splitId, isPaid)
        }

        binding.rvExpenses.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        viewModel.getExpensesForFriend(friendId).observe(viewLifecycleOwner) { splits ->
            adapter.submitList(splits)

            val totalOwed = splits.sumOf { it.splitAmount }
            val totalPaid = splits.filter { it.isPaid }.sumOf { it.splitAmount }
            val totalPending = totalOwed - totalPaid

            binding.tvTotalOwed.text = DateTimeUtil.formatCurrency(totalOwed)
            binding.tvTotalPaid.text = DateTimeUtil.formatCurrency(totalPaid)
            binding.tvTotalPending.text = DateTimeUtil.formatCurrency(totalPending)

            binding.tvNoExpenses.visibility = if (splits.isEmpty()) View.VISIBLE else View.GONE
            binding.rvExpenses.visibility = if (splits.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
