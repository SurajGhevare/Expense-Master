package com.expensetracker.ui

import androidx.lifecycle.*
import com.expensetracker.data.db.Expense
import com.expensetracker.data.db.Friend
import com.expensetracker.data.repository.ExpenseRepository
import kotlinx.coroutines.launch

class MainViewModel(private val repository: ExpenseRepository) : ViewModel() {

    val allExpensesWithSplits = repository.allExpensesWithSplits
    val totalSpent = repository.totalSpent
    val totalPending = repository.totalPending
    val recentExpenses = repository.recentExpenses
    val friendBalances = repository.friendBalances
    val allFriends = repository.allFriends
    val monthlyExpenseSummary = repository.monthlyExpenseSummary

    fun addExpenseWithSplits(expense: Expense, friendIds: List<Long>) = viewModelScope.launch {
        repository.addExpenseWithSplits(expense, friendIds)
    }

    fun updateExpenseWithSplits(expense: Expense, friendIds: List<Long>) = viewModelScope.launch {
        repository.updateExpenseWithSplits(expense, friendIds)
    }

    fun deleteExpense(expense: Expense) = viewModelScope.launch {
        repository.deleteExpense(expense)
    }

    suspend fun getExpenseWithSplitsById(id: Long) = repository.getExpenseWithSplitsById(id)

    fun markSplitAsPaid(splitId: Long, isPaid: Boolean) = viewModelScope.launch {
        repository.markSplitAsPaid(splitId, isPaid)
    }

    fun addFriend(friend: Friend) = viewModelScope.launch {
        repository.addFriend(friend)
    }

    fun updateFriend(friend: Friend) = viewModelScope.launch {
        repository.updateFriend(friend)
    }

    fun deleteFriend(friend: Friend) = viewModelScope.launch {
        repository.deleteFriend(friend)
    }

    fun getExpensesForFriend(friendId: Long) = repository.getExpensesForFriend(friendId)
}

class MainViewModelFactory(private val repository: ExpenseRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
