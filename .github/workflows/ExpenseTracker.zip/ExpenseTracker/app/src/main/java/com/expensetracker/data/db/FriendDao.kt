package com.expensetracker.data.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface FriendDao {

    @Query("SELECT * FROM friends ORDER BY name ASC")
    fun getAllFriends(): LiveData<List<Friend>>

    @Query("SELECT * FROM friends ORDER BY name ASC")
    suspend fun getAllFriendsSync(): List<Friend>

    @Query("SELECT * FROM friends WHERE id = :id")
    suspend fun getFriendById(id: Long): Friend?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriend(friend: Friend): Long

    @Update
    suspend fun updateFriend(friend: Friend)

    @Delete
    suspend fun deleteFriend(friend: Friend)

    @Query("SELECT COUNT(*) FROM friends")
    suspend fun getFriendCount(): Int

    @Query("""
        SELECT 
            f.id as friendId,
            f.name as friendName,
            COALESCE(SUM(es.splitAmount), 0) as totalOwed,
            COALESCE(SUM(CASE WHEN es.isPaid = 1 THEN es.splitAmount ELSE 0 END), 0) as paidAmount
        FROM friends f
        LEFT JOIN expense_splits es ON f.id = es.friendId
        GROUP BY f.id, f.name
        ORDER BY (COALESCE(SUM(es.splitAmount), 0) - COALESCE(SUM(CASE WHEN es.isPaid = 1 THEN es.splitAmount ELSE 0 END), 0)) DESC
    """)
    fun getFriendBalances(): LiveData<List<FriendBalance>>

    @Query("""
        SELECT 
            es.id as splitId,
            es.expenseId,
            f.id as friendId,
            f.name as friendName,
            e.description as expenseDescription,
            es.splitAmount,
            es.isPaid,
            e.createdAt,
            e.amount as totalAmount
        FROM expense_splits es
        JOIN friends f ON es.friendId = f.id
        JOIN expenses e ON es.expenseId = e.id
        WHERE f.id = :friendId
        ORDER BY e.createdAt DESC
    """)
    fun getExpensesForFriend(friendId: Long): LiveData<List<ExpenseSplitWithFriend>>
}
