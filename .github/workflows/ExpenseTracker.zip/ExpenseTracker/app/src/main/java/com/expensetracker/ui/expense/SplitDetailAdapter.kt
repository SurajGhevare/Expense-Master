package com.expensetracker.ui.expense

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.ExpenseSplit
import com.expensetracker.databinding.ItemSplitDetailBinding
import com.expensetracker.util.DateTimeUtil

class SplitDetailAdapter(
    private val splits: List<ExpenseSplit>,
    private val onPaymentToggle: (Long, Boolean) -> Unit
) : RecyclerView.Adapter<SplitDetailAdapter.ViewHolder>() {

    // We need friend names — pass them in from parent
    private val friendNames = mutableMapOf<Long, String>()

    fun setFriendNames(names: Map<Long, String>) {
        friendNames.putAll(names)
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val binding: ItemSplitDetailBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(split: ExpenseSplit) {
            binding.tvFriendName.text = friendNames[split.friendId] ?: "Friend #${split.friendId}"
            binding.tvSplitAmount.text = DateTimeUtil.formatCurrency(split.splitAmount)
            binding.switchPaid.isChecked = split.isPaid
            binding.tvStatus.text = if (split.isPaid) "Paid" else "Pending"

            binding.switchPaid.setOnCheckedChangeListener { _, isChecked ->
                onPaymentToggle(split.id, isChecked)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSplitDetailBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(splits[position])
    }

    override fun getItemCount() = splits.size
}
