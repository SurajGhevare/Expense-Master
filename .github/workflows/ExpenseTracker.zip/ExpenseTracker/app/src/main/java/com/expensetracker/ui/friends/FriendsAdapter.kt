package com.expensetracker.ui.friends

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.expensetracker.data.db.Friend
import com.expensetracker.databinding.ItemFriendBinding

class FriendsAdapter(
    private val onEdit: (Friend) -> Unit,
    private val onDelete: (Friend) -> Unit
) : ListAdapter<Friend, FriendsAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemFriendBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(friend: Friend) {
            binding.tvName.text = friend.name
            binding.tvInitial.text = friend.name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            binding.tvEmail.text = friend.email.ifEmpty { friend.phone.ifEmpty { "No contact info" } }
            binding.btnEdit.setOnClickListener { onEdit(friend) }
            binding.btnDelete.setOnClickListener { onDelete(friend) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemFriendBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<Friend>() {
        override fun areItemsTheSame(oldItem: Friend, newItem: Friend) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Friend, newItem: Friend) = oldItem == newItem
    }
}
