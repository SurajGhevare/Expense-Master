package com.expensetracker.data.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun getAllExpenses(): LiveData<List<Expense>>

    @Transaction
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun getAllExpensesWithSplits(): LiveData<List<ExpenseWithSplits>>

    @Transaction
    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseWithSplitsById(id: Long): ExpenseWithSplits?

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseById(id: Long): Expense?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses")
    fun getTotalSpent(): LiveData<Double>

    @Query("""
        SELECT COALESCE(SUM(es.splitAmount), 0) 
        FROM expense_splits es 
        WHERE es.isPaid = 0
    """)
    fun getTotalPending(): LiveData<Double>

    @Query("SELECT * FROM expenses ORDER BY createdAt DESC LIMIT :limit")
    fun getRecentExpenses(limit: Int = 10): LiveData<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSplits(splits: List<ExpenseSplit>)

    @Query("DELETE FROM expense_splits WHERE expenseId = :expenseId")
    suspend fun deleteSplitsForExpense(expenseId: Long)

    @Query("UPDATE expense_splits SET isPaid = :isPaid, paidAt = :paidAt WHERE id = :splitId")
    suspend fun updateSplitPaymentStatus(splitId: Long, isPaid: Boolean, paidAt: Long?)

    @Query("""
        SELECT COALESCE(SUM(amount), 0) FROM expenses 
        WHERE createdAt >= :startTime AND createdAt <= :endTime
    """)
    suspend fun getTotalSpentBetween(startTime: Long, endTime: Long): Double

    @Query("""
        SELECT strftime('%Y', datetime(createdAt/1000, 'unixepoch')) as year,
               strftime('%m', datetime(createdAt/1000, 'unixepoch')) as month,
               COUNT(*) as count,
               SUM(amount) as total
        FROM expenses
        GROUP BY year, month
        ORDER BY year DESC, month DESC
    """)
    fun getMonthlyExpenseSummary(): LiveData<List<MonthlyExpenseSummary>>
}

data class MonthlyExpenseSummary(
    val year: String,
    val month: String,
    val count: Int,
    val total: Double
)
